const { ActivityType } = require('discord.js');
const logger = require('../utils/logger.js');
const config = require('../config.js');

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        logger.info(`Bot is ready! Logged in as ${client.user.tag}`);
        logger.info(`Bot is in ${client.guilds.cache.size} guilds`);
        logger.info(`Serving ${client.users.cache.size} users`);

        // Set bot activity
        const activities = [
            { name: `${config.prefix}help | ${client.guilds.cache.size} servers`, type: ActivityType.Watching },
            { name: `${config.prefix}help | ${client.users.cache.size} users`, type: ActivityType.Listening },
            { name: 'music and moderating servers', type: ActivityType.Playing },
            { name: 'for new commands', type: ActivityType.Watching }
        ];

        let activityIndex = 0;

        // Set initial activity
        client.user.setActivity(activities[activityIndex]);

        // Change activity every 30 seconds
        setInterval(() => {
            activityIndex = (activityIndex + 1) % activities.length;
            const activity = activities[activityIndex];
            
            // Update member count in activity
            if (activity.name.includes('servers')) {
                activity.name = `${config.prefix}help | ${client.guilds.cache.size} servers`;
            } else if (activity.name.includes('users')) {
                activity.name = `${config.prefix}help | ${client.users.cache.size} users`;
            }
            
            client.user.setActivity(activity);
        }, 30000);

        // Clean up expired mutes every 5 minutes
        setInterval(async () => {
            try {
                const database = require('../database/database.js');
                const expiredMutes = await database.all(
                    'SELECT * FROM muted_users WHERE muted_until IS NOT NULL AND muted_until < ?',
                    [Date.now()]
                );

                for (const mute of expiredMutes) {
                    const guild = client.guilds.cache.get(mute.guild_id);
                    if (guild) {
                        const member = guild.members.cache.get(mute.user_id);
                        if (member) {
                            try {
                                await member.timeout(null);
                                await database.run(
                                    'DELETE FROM muted_users WHERE id = ?',
                                    [mute.id]
                                );
                                logger.info(`Auto-unmuted ${member.user.tag} in ${guild.name}`);
                            } catch (error) {
                                logger.error('Error auto-unmuting user:', error);
                            }
                        }
                    }
                }
            } catch (error) {
                logger.error('Error cleaning up expired mutes:', error);
            }
        }, 5 * 60 * 1000); // 5 minutes
    }
};
