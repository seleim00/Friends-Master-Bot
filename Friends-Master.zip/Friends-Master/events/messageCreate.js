const config = require('../config.js');
const database = require('../database/database.js');
const { isRateLimited } = require('../utils/rateLimiter.js');
const logger = require('../utils/logger.js');

function calculateLevel(xp) {
    return Math.floor(0.1 * Math.sqrt(xp)) + 1;
}

module.exports = {
    name: 'messageCreate',
    async execute(message, client) {
        // Ignore bot messages
        if (message.author.bot) return;

        // Handle XP gain for leveling system
        await handleXPGain(message);

        // Get guild prefix
        let prefix = config.prefix;
        try {
            const guildSettings = await database.getGuildSettings(message.guild?.id);
            if (guildSettings?.prefix) {
                prefix = guildSettings.prefix;
            }
        } catch (error) {
            logger.error('Error fetching guild prefix:', error);
        }

        // Check if message starts with prefix
        if (!message.content.startsWith(prefix)) return;

        // Parse command and arguments
        const args = message.content.slice(prefix.length).trim().split(/ +/);
        const commandName = args.shift().toLowerCase();

        // Find command (including aliases)
        const command = client.commands.get(commandName) || 
                       client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));

        if (!command) return;

        // Rate limiting
        if (isRateLimited(message.author.id, commandName)) {
            return message.reply('You are being rate limited! Please slow down.');
        }

        // Log command usage
        try {
            await database.run(
                'INSERT INTO command_stats (command_name, user_id, guild_id) VALUES (?, ?, ?)',
                [commandName, message.author.id, message.guild?.id || null]
            );
        } catch (error) {
            logger.error('Error logging command usage:', error);
        }

        // Execute command
        try {
            await command.execute(message, args, client);
        } catch (error) {
            logger.error('Error executing command:', error);
            message.reply('There was an error executing this command!');
        }
    }
};

async function handleXPGain(message) {
    // Only give XP in guilds
    if (!message.guild) return;

    try {
        await database.createUser(message.author.id, message.guild.id);
        const userData = await database.getUser(message.author.id, message.guild.id);
        
        const now = Date.now();
        const lastXP = userData?.last_xp || 0;
        
        // XP cooldown check
        if (now - lastXP < config.leveling.xpCooldown) return;

        // Calculate XP to give (random amount)
        const baseXP = config.leveling.xpPerMessage;
        const randomBonus = Math.floor(Math.random() * 10); // 0-9 bonus XP
        const xpToGive = baseXP + randomBonus;

        // Get current level
        const oldXP = userData?.xp || 0;
        const oldLevel = calculateLevel(oldXP);

        // Update XP and last XP timestamp
        await database.updateUserXP(message.author.id, message.guild.id, xpToGive);
        await database.run(
            'UPDATE users SET last_xp = ? WHERE user_id = ? AND guild_id = ?',
            [now, message.author.id, message.guild.id]
        );

        // Check for level up
        const newXP = oldXP + xpToGive;
        const newLevel = calculateLevel(newXP);

        if (newLevel > oldLevel) {
            await database.updateUserLevel(message.author.id, message.guild.id, newLevel);
            
            // Send level up message
            const levelUpEmbed = {
                title: '🎉 Level Up!',
                description: `Congratulations ${message.author}! You reached level **${newLevel}**!`,
                color: parseInt(config.colors.success.replace('#', ''), 16),
                thumbnail: {
                    url: message.author.displayAvatarURL({ dynamic: true })
                },
                fields: [
                    {
                        name: 'New Level',
                        value: newLevel.toString(),
                        inline: true
                    },
                    {
                        name: 'Total XP',
                        value: newXP.toLocaleString(),
                        inline: true
                    }
                ]
            };

            message.channel.send({ embeds: [levelUpEmbed] });
        }
    } catch (error) {
        logger.error('Error handling XP gain:', error);
    }
}
