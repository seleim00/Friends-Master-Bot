const { EmbedBuilder } = require('discord.js');
const database = require('../database/database.js');
const config = require('../config.js');
const logger = require('../utils/logger.js');

module.exports = {
    name: 'guildMemberAdd',
    async execute(member, client) {
        try {
            // Create user in database
            await database.createUser(member.id, member.guild.id);
            
            // Get guild settings for welcome channel
            const guildSettings = await database.getGuildSettings(member.guild.id);
            
            if (!guildSettings?.welcome_channel) {
                // Try to find a general or welcome channel
                const welcomeChannel = member.guild.channels.cache.find(channel => 
                    channel.name.includes('welcome') || 
                    channel.name.includes('general') ||
                    channel.name.includes('main')
                );
                
                if (!welcomeChannel) return;
                
                // Send welcome message
                const embed = new EmbedBuilder()
                    .setTitle('👋 Welcome!')
                    .setDescription(`Welcome to **${member.guild.name}**, ${member}!`)
                    .addFields(
                        { name: 'Member Count', value: member.guild.memberCount.toString(), inline: true },
                        { name: 'Account Created', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true }
                    )
                    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                    .setColor(config.colors.success)
                    .setFooter({ text: `User ID: ${member.id}` })
                    .setTimestamp();

                welcomeChannel.send({ embeds: [embed] });
            }
            
            logger.info(`New member joined: ${member.user.tag} in ${member.guild.name}`);
        } catch (error) {
            logger.error('Error handling member join:', error);
        }
    }
};
