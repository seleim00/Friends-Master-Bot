const { Client, GatewayIntentBits, Collection } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('./config.js');
const database = require('./database/database.js');
const logger = require('./utils/logger.js');

// Create Discord client with necessary intents
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildPresences
    ]
});

// Initialize command collections
client.commands = new Collection();
client.cooldowns = new Collection();
client.musicQueues = new Collection();

// Load commands from all command files
const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));
for (const file of commandFiles) {
    const commandModule = require(`./commands/${file}`);
    if (commandModule.commands) {
        for (const [name, command] of Object.entries(commandModule.commands)) {
            client.commands.set(name, command);
        }
    }
}

// Load event handlers
const eventFiles = fs.readdirSync('./events').filter(file => file.endsWith('.js'));
for (const file of eventFiles) {
    const event = require(`./events/${file}`);
    if (event.once) {
        client.once(event.name, (...args) => event.execute(...args, client));
    } else {
        client.on(event.name, (...args) => event.execute(...args, client));
    }
}

// Global error handling
process.on('unhandledRejection', error => {
    logger.error('Unhandled promise rejection:', error);
});

process.on('uncaughtException', error => {
    logger.error('Uncaught exception:', error);
    process.exit(1);
});

// Initialize database and start bot
async function startBot() {
    try {
        await database.initialize();
        logger.info('Database initialized successfully');
        
        await client.login(process.env.DISCORD_TOKEN || config.token);
        logger.info('Bot logged in successfully');
    } catch (error) {
        logger.error('Failed to start bot:', error);
        process.exit(1);
    }
}

startBot();

module.exports = client;
