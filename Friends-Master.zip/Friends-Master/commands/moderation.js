const { PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const database = require('../database/database.js');
const { checkPermissions } = require('../utils/permissions.js');
const { createEmbed } = require('../utils/embed.js');
const logger = require('../utils/logger.js');

const commands = {
    kick: {
        name: 'kick',
        description: 'Kick a user from the server',
        usage: 'kick <@user> [reason]',
        permissions: [PermissionFlagsBits.KickMembers],
        async execute(message, args) {
            if (!checkPermissions(message.member, this.permissions)) {
                return message.reply('You do not have permission to use this command.');
            }

            const user = message.mentions.users.first();
            if (!user) {
                return message.reply('Please mention a user to kick.');
            }

            const member = message.guild.members.cache.get(user.id);
            if (!member) {
                return message.reply('User not found in this server.');
            }

            if (!member.kickable) {
                return message.reply('I cannot kick this user. They may have higher permissions than me.');
            }

            const reason = args.slice(1).join(' ') || 'No reason provided';

            try {
                await member.kick(reason);
                
                const embed = createEmbed(
                    'User Kicked',
                    `${user.tag} has been kicked from the server.\nReason: ${reason}`,
                    'warning'
                );
                
                message.reply({ embeds: [embed] });
                logger.info(`${user.tag} was kicked by ${message.author.tag} for: ${reason}`);
            } catch (error) {
                logger.error('Error kicking user:', error);
                message.reply('Failed to kick the user. Please check my permissions.');
            }
        }
    },

    ban: {
        name: 'ban',
        description: 'Ban a user from the server',
        usage: 'ban <@user> [reason]',
        permissions: [PermissionFlagsBits.BanMembers],
        async execute(message, args) {
            if (!checkPermissions(message.member, this.permissions)) {
                return message.reply('You do not have permission to use this command.');
            }

            const user = message.mentions.users.first();
            if (!user) {
                return message.reply('Please mention a user to ban.');
            }

            const member = message.guild.members.cache.get(user.id);
            if (member && !member.bannable) {
                return message.reply('I cannot ban this user. They may have higher permissions than me.');
            }

            const reason = args.slice(1).join(' ') || 'No reason provided';

            try {
                await message.guild.members.ban(user.id, { reason: reason });
                
                const embed = createEmbed(
                    'User Banned',
                    `${user.tag} has been banned from the server.\nReason: ${reason}`,
                    'error'
                );
                
                message.reply({ embeds: [embed] });
                logger.info(`${user.tag} was banned by ${message.author.tag} for: ${reason}`);
            } catch (error) {
                logger.error('Error banning user:', error);
                message.reply('Failed to ban the user. Please check my permissions.');
            }
        }
    },

    unban: {
        name: 'unban',
        description: 'Unban a user from the server',
        usage: 'unban <user_id>',
        permissions: [PermissionFlagsBits.BanMembers],
        async execute(message, args) {
            if (!checkPermissions(message.member, this.permissions)) {
                return message.reply('You do not have permission to use this command.');
            }

            const userId = args[0];
            if (!userId) {
                return message.reply('Please provide a user ID to unban.');
            }

            try {
                await message.guild.members.unban(userId);
                
                const embed = createEmbed(
                    'User Unbanned',
                    `User with ID ${userId} has been unbanned.`,
                    'success'
                );
                
                message.reply({ embeds: [embed] });
                logger.info(`User ${userId} was unbanned by ${message.author.tag}`);
            } catch (error) {
                logger.error('Error unbanning user:', error);
                message.reply('Failed to unban the user. Make sure the user ID is correct and they are banned.');
            }
        }
    },

    warn: {
        name: 'warn',
        description: 'Warn a user',
        usage: 'warn <@user> <reason>',
        permissions: [PermissionFlagsBits.ModerateMembers],
        async execute(message, args) {
            if (!checkPermissions(message.member, this.permissions)) {
                return message.reply('You do not have permission to use this command.');
            }

            const user = message.mentions.users.first();
            if (!user) {
                return message.reply('Please mention a user to warn.');
            }

            const reason = args.slice(1).join(' ');
            if (!reason) {
                return message.reply('Please provide a reason for the warning.');
            }

            try {
                await database.addWarning(user.id, message.guild.id, message.author.id, reason);
                
                const embed = createEmbed(
                    'User Warned',
                    `${user.tag} has been warned.\nReason: ${reason}`,
                    'warning'
                );
                
                message.reply({ embeds: [embed] });
                
                // Try to DM the user
                try {
                    const dmEmbed = createEmbed(
                        `Warning in ${message.guild.name}`,
                        `You have been warned for: ${reason}`,
                        'warning'
                    );
                    await user.send({ embeds: [dmEmbed] });
                } catch (dmError) {
                    // User has DMs disabled
                }
                
                logger.info(`${user.tag} was warned by ${message.author.tag} for: ${reason}`);
            } catch (error) {
                logger.error('Error warning user:', error);
                message.reply('Failed to warn the user.');
            }
        }
    },

    warnings: {
        name: 'warnings',
        description: 'View warnings for a user',
        usage: 'warnings <@user>',
        permissions: [PermissionFlagsBits.ModerateMembers],
        async execute(message, args) {
            if (!checkPermissions(message.member, this.permissions)) {
                return message.reply('You do not have permission to use this command.');
            }

            const user = message.mentions.users.first() || message.author;
            
            try {
                const warnings = await database.getWarnings(user.id, message.guild.id);
                
                if (warnings.length === 0) {
                    const embed = createEmbed(
                        'No Warnings',
                        `${user.tag} has no warnings.`,
                        'success'
                    );
                    return message.reply({ embeds: [embed] });
                }

                const embed = new EmbedBuilder()
                    .setTitle(`Warnings for ${user.tag}`)
                    .setColor('#FAA61A')
                    .setThumbnail(user.displayAvatarURL());

                warnings.slice(0, 10).forEach((warning, index) => {
                    const date = new Date(warning.timestamp).toLocaleDateString();
                    embed.addFields({
                        name: `Warning ${index + 1} - ${date}`,
                        value: warning.reason,
                        inline: false
                    });
                });

                if (warnings.length > 10) {
                    embed.setFooter({ text: `Showing 10 of ${warnings.length} warnings` });
                }

                message.reply({ embeds: [embed] });
            } catch (error) {
                logger.error('Error fetching warnings:', error);
                message.reply('Failed to fetch warnings.');
            }
        }
    },

    mute: {
        name: 'mute',
        description: 'Mute a user',
        usage: 'mute <@user> [duration] [reason]',
        permissions: [PermissionFlagsBits.ModerateMembers],
        async execute(message, args) {
            if (!checkPermissions(message.member, this.permissions)) {
                return message.reply('You do not have permission to use this command.');
            }

            const user = message.mentions.users.first();
            if (!user) {
                return message.reply('Please mention a user to mute.');
            }

            const member = message.guild.members.cache.get(user.id);
            if (!member) {
                return message.reply('User not found in this server.');
            }

            // Parse duration (e.g., "10m", "1h", "1d")
            let duration = null;
            let reason = args.slice(1).join(' ') || 'No reason provided';
            
            if (args[1] && /^\d+[mhd]$/.test(args[1])) {
                const durationStr = args[1];
                const amount = parseInt(durationStr);
                const unit = durationStr.slice(-1);
                
                switch (unit) {
                    case 'm':
                        duration = amount * 60 * 1000;
                        break;
                    case 'h':
                        duration = amount * 60 * 60 * 1000;
                        break;
                    case 'd':
                        duration = amount * 24 * 60 * 60 * 1000;
                        break;
                }
                
                reason = args.slice(2).join(' ') || 'No reason provided';
            }

            try {
                const until = duration ? Date.now() + duration : null;
                await member.timeout(duration, reason);
                
                // Save to database
                await database.run(
                    'INSERT OR REPLACE INTO muted_users (user_id, guild_id, muted_until, reason, moderator_id) VALUES (?, ?, ?, ?, ?)',
                    [user.id, message.guild.id, until, reason, message.author.id]
                );

                const durationText = duration ? ` for ${args[1]}` : ' indefinitely';
                const embed = createEmbed(
                    'User Muted',
                    `${user.tag} has been muted${durationText}.\nReason: ${reason}`,
                    'warning'
                );
                
                message.reply({ embeds: [embed] });
                logger.info(`${user.tag} was muted by ${message.author.tag} for: ${reason}`);
            } catch (error) {
                logger.error('Error muting user:', error);
                message.reply('Failed to mute the user. Please check my permissions.');
            }
        }
    },

    unmute: {
        name: 'unmute',
        description: 'Unmute a user',
        usage: 'unmute <@user>',
        permissions: [PermissionFlagsBits.ModerateMembers],
        async execute(message, args) {
            if (!checkPermissions(message.member, this.permissions)) {
                return message.reply('You do not have permission to use this command.');
            }

            const user = message.mentions.users.first();
            if (!user) {
                return message.reply('Please mention a user to unmute.');
            }

            const member = message.guild.members.cache.get(user.id);
            if (!member) {
                return message.reply('User not found in this server.');
            }

            try {
                await member.timeout(null);
                
                // Remove from database
                await database.run(
                    'DELETE FROM muted_users WHERE user_id = ? AND guild_id = ?',
                    [user.id, message.guild.id]
                );

                const embed = createEmbed(
                    'User Unmuted',
                    `${user.tag} has been unmuted.`,
                    'success'
                );
                
                message.reply({ embeds: [embed] });
                logger.info(`${user.tag} was unmuted by ${message.author.tag}`);
            } catch (error) {
                logger.error('Error unmuting user:', error);
                message.reply('Failed to unmute the user.');
            }
        }
    },

    clear: {
        name: 'clear',
        description: 'Delete messages from the current channel',
        usage: 'clear <amount>',
        permissions: [PermissionFlagsBits.ManageMessages],
        async execute(message, args) {
            if (!checkPermissions(message.member, this.permissions)) {
                return message.reply('You do not have permission to use this command.');
            }

            const amount = parseInt(args[0]);
            if (!amount || amount < 1 || amount > 100) {
                return message.reply('Please provide a number between 1 and 100.');
            }

            try {
                const deleted = await message.channel.bulkDelete(amount + 1, true);
                
                const embed = createEmbed(
                    'Messages Cleared',
                    `Successfully deleted ${deleted.size - 1} messages.`,
                    'success'
                );
                
                const reply = await message.channel.send({ embeds: [embed] });
                setTimeout(() => reply.delete().catch(() => {}), 5000);
                
                logger.info(`${message.author.tag} cleared ${deleted.size - 1} messages in ${message.channel.name}`);
            } catch (error) {
                logger.error('Error clearing messages:', error);
                message.reply('Failed to clear messages. Messages might be too old (older than 14 days).');
            }
        }
    }
};

module.exports = { commands };
