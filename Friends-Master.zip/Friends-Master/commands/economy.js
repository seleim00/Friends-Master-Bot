const { EmbedBuilder } = require('discord.js');
const database = require('../database/database.js');
const { createEmbed } = require('../utils/embed.js');
const config = require('../config.js');
const logger = require('../utils/logger.js');

const commands = {
    balance: {
        name: 'balance',
        aliases: ['bal'],
        description: 'Check your or another user\'s balance',
        usage: 'balance [@user]',
        async execute(message, args) {
            const target = message.mentions.users.first() || message.author;
            
            try {
                await database.createUser(target.id, message.guild.id);
                const userData = await database.getUser(target.id, message.guild.id);
                
                const balance = userData?.balance || 0;
                const isOwn = target.id === message.author.id;

                const embed = createEmbed(
                    `${config.economy.currencySymbol} ${isOwn ? 'Your' : `${target.username}'s`} Balance`,
                    `**${balance.toLocaleString()}** ${config.economy.currencyName}`,
                    'success'
                );

                message.reply({ embeds: [embed] });
            } catch (error) {
                logger.error('Error fetching balance:', error);
                message.reply('Failed to fetch balance data.');
            }
        }
    },

    daily: {
        name: 'daily',
        description: 'Claim your daily reward',
        usage: 'daily',
        async execute(message, args) {
            try {
                await database.createUser(message.author.id, message.guild.id);
                const userData = await database.getUser(message.author.id, message.guild.id);
                
                const now = Date.now();
                const lastDaily = userData?.last_daily || 0;
                const cooldown = 24 * 60 * 60 * 1000; // 24 hours

                if (now - lastDaily < cooldown) {
                    const timeLeft = cooldown - (now - lastDaily);
                    const hours = Math.floor(timeLeft / (60 * 60 * 1000));
                    const minutes = Math.floor((timeLeft % (60 * 60 * 1000)) / (60 * 1000));

                    const embed = createEmbed(
                        'Daily Cooldown',
                        `You can claim your daily reward in **${hours}h ${minutes}m**`,
                        'warning'
                    );
                    
                    return message.reply({ embeds: [embed] });
                }

                const amount = config.economy.dailyAmount;
                await database.updateUserBalance(message.author.id, message.guild.id, amount);
                await database.setLastDaily(message.author.id, message.guild.id, now);

                const embed = createEmbed(
                    'Daily Reward Claimed!',
                    `You received **${amount}** ${config.economy.currencyName} ${config.economy.currencySymbol}`,
                    'success'
                );

                message.reply({ embeds: [embed] });
            } catch (error) {
                logger.error('Error claiming daily reward:', error);
                message.reply('Failed to claim daily reward.');
            }
        }
    },

    pay: {
        name: 'pay',
        description: 'Transfer money to another user',
        usage: 'pay <@user> <amount>',
        async execute(message, args) {
            const target = message.mentions.users.first();
            if (!target) {
                return message.reply('Please mention a user to pay!');
            }

            if (target.id === message.author.id) {
                return message.reply('You cannot pay yourself!');
            }

            if (target.bot) {
                return message.reply('You cannot pay bots!');
            }

            const amount = parseInt(args[1]);
            if (!amount || amount <= 0) {
                return message.reply('Please provide a valid amount to pay!');
            }

            try {
                await database.createUser(message.author.id, message.guild.id);
                await database.createUser(target.id, message.guild.id);
                
                const senderData = await database.getUser(message.author.id, message.guild.id);
                const senderBalance = senderData?.balance || 0;

                if (senderBalance < amount) {
                    return message.reply(`You don't have enough ${config.economy.currencyName}! You have ${senderBalance}.`);
                }

                await database.updateUserBalance(message.author.id, message.guild.id, -amount);
                await database.updateUserBalance(target.id, message.guild.id, amount);

                const embed = createEmbed(
                    'Payment Successful',
                    `You paid **${amount}** ${config.economy.currencyName} to ${target}`,
                    'success'
                );

                message.reply({ embeds: [embed] });
            } catch (error) {
                logger.error('Error processing payment:', error);
                message.reply('Failed to process payment.');
            }
        }
    },

    work: {
        name: 'work',
        description: 'Work to earn money',
        usage: 'work',
        async execute(message, args) {
            try {
                await database.createUser(message.author.id, message.guild.id);
                
                // Check cooldown (1 hour)
                const userData = await database.getUser(message.author.id, message.guild.id);
                const lastWork = userData?.last_work || 0;
                const cooldown = 60 * 60 * 1000; // 1 hour
                const now = Date.now();

                if (now - lastWork < cooldown) {
                    const timeLeft = cooldown - (now - lastWork);
                    const minutes = Math.floor(timeLeft / (60 * 1000));
                    
                    const embed = createEmbed(
                        'Work Cooldown',
                        `You can work again in **${minutes}** minutes`,
                        'warning'
                    );
                    
                    return message.reply({ embeds: [embed] });
                }

                const jobs = [
                    'programmer',
                    'designer',
                    'teacher',
                    'chef',
                    'mechanic',
                    'artist',
                    'writer',
                    'doctor',
                    'engineer',
                    'musician'
                ];

                const job = jobs[Math.floor(Math.random() * jobs.length)];
                const earnings = Math.floor(Math.random() * 50) + 25; // 25-74 coins

                await database.updateUserBalance(message.author.id, message.guild.id, earnings);
                await database.run(
                    'UPDATE users SET last_work = ? WHERE user_id = ? AND guild_id = ?',
                    [now, message.author.id, message.guild.id]
                );

                const embed = createEmbed(
                    'Work Complete!',
                    `You worked as a **${job}** and earned **${earnings}** ${config.economy.currencyName} ${config.economy.currencySymbol}`,
                    'success'
                );

                message.reply({ embeds: [embed] });
            } catch (error) {
                logger.error('Error processing work command:', error);
                message.reply('Failed to process work command.');
            }
        }
    },

    gamble: {
        name: 'gamble',
        aliases: ['bet'],
        description: 'Gamble your money',
        usage: 'gamble <amount>',
        async execute(message, args) {
            const amount = parseInt(args[0]);
            if (!amount || amount <= 0) {
                return message.reply('Please provide a valid amount to gamble!');
            }

            try {
                await database.createUser(message.author.id, message.guild.id);
                const userData = await database.getUser(message.author.id, message.guild.id);
                const balance = userData?.balance || 0;

                if (balance < amount) {
                    return message.reply(`You don't have enough ${config.economy.currencyName}! You have ${balance}.`);
                }

                const chance = Math.random();
                let winnings = 0;
                let result = '';

                if (chance < 0.45) {
                    // Win (45% chance)
                    winnings = Math.floor(amount * 1.8);
                    result = `🎉 You won **${winnings}** ${config.economy.currencyName}!`;
                } else if (chance < 0.48) {
                    // Jackpot (3% chance)
                    winnings = amount * 5;
                    result = `🎰 JACKPOT! You won **${winnings}** ${config.economy.currencyName}!`;
                } else {
                    // Lose (52% chance)
                    winnings = -amount;
                    result = `😔 You lost **${amount}** ${config.economy.currencyName}.`;
                }

                await database.updateUserBalance(message.author.id, message.guild.id, winnings);

                const embed = new EmbedBuilder()
                    .setTitle('🎲 Gambling Results')
                    .setDescription(result)
                    .setColor(winnings > 0 ? config.colors.success : config.colors.error)
                    .addFields({
                        name: 'Change',
                        value: `${winnings > 0 ? '+' : ''}${winnings} ${config.economy.currencyName}`,
                        inline: true
                    });

                message.reply({ embeds: [embed] });
            } catch (error) {
                logger.error('Error processing gamble command:', error);
                message.reply('Failed to process gamble command.');
            }
        }
    },

    leaderboard: {
        name: 'leaderboard',
        aliases: ['lb', 'top'],
        description: 'View the server\'s richest users',
        usage: 'leaderboard',
        async execute(message, args) {
            try {
                const topUsers = await database.all(
                    'SELECT user_id, balance FROM users WHERE guild_id = ? ORDER BY balance DESC LIMIT 10',
                    [message.guild.id]
                );

                if (topUsers.length === 0) {
                    return message.reply('No economy data found for this server!');
                }

                const embed = new EmbedBuilder()
                    .setTitle(`💰 ${message.guild.name} - Economy Leaderboard`)
                    .setColor(config.colors.primary)
                    .setThumbnail(message.guild.iconURL());

                let description = '';
                for (let i = 0; i < topUsers.length; i++) {
                    const user = topUsers[i];
                    const member = message.guild.members.cache.get(user.user_id);
                    const username = member ? member.user.username : 'Unknown User';
                    
                    const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}.`;
                    description += `${medal} **${username}** - ${user.balance.toLocaleString()} ${config.economy.currencyName}\n`;
                }

                embed.setDescription(description);
                message.reply({ embeds: [embed] });
            } catch (error) {
                logger.error('Error fetching leaderboard:', error);
                message.reply('Failed to fetch leaderboard data.');
            }
        }
    },

    shop: {
        name: 'shop',
        description: 'View the economy shop',
        usage: 'shop',
        async execute(message, args) {
            const items = [
                { name: 'VIP Role (7 days)', price: 1000, description: 'Get a special VIP role for 7 days' },
                { name: 'Custom Status', price: 500, description: 'Set a custom status message' },
                { name: 'Color Role', price: 750, description: 'Get a colored role of your choice' },
                { name: 'Extra Daily Bonus', price: 2000, description: 'Double your daily reward for 7 days' }
            ];

            const embed = new EmbedBuilder()
                .setTitle('🏪 Economy Shop')
                .setDescription('Use `buy <item number>` to purchase items')
                .setColor(config.colors.primary);

            items.forEach((item, index) => {
                embed.addFields({
                    name: `${index + 1}. ${item.name}`,
                    value: `**Price:** ${item.price} ${config.economy.currencyName}\n${item.description}`,
                    inline: false
                });
            });

            message.reply({ embeds: [embed] });
        }
    },

    buy: {
        name: 'buy',
        description: 'Buy an item from the shop',
        usage: 'buy <item number>',
        async execute(message, args) {
            const itemNumber = parseInt(args[0]);
            if (!itemNumber || itemNumber < 1 || itemNumber > 4) {
                return message.reply('Please provide a valid item number (1-4)!');
            }

            const items = [
                { name: 'VIP Role (7 days)', price: 1000 },
                { name: 'Custom Status', price: 500 },
                { name: 'Color Role', price: 750 },
                { name: 'Extra Daily Bonus', price: 2000 }
            ];

            const item = items[itemNumber - 1];

            try {
                await database.createUser(message.author.id, message.guild.id);
                const userData = await database.getUser(message.author.id, message.guild.id);
                const balance = userData?.balance || 0;

                if (balance < item.price) {
                    return message.reply(`You don't have enough ${config.economy.currencyName}! You need ${item.price} but have ${balance}.`);
                }

                await database.updateUserBalance(message.author.id, message.guild.id, -item.price);

                const embed = createEmbed(
                    'Purchase Successful!',
                    `You bought **${item.name}** for **${item.price}** ${config.economy.currencyName}!\n\n*Note: This is a demo shop. Items don't actually function.*`,
                    'success'
                );

                message.reply({ embeds: [embed] });
            } catch (error) {
                logger.error('Error processing purchase:', error);
                message.reply('Failed to process purchase.');
            }
        }
    }
};

module.exports = { commands };
