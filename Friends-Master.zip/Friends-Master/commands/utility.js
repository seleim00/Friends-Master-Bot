const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { createEmbed } = require('../utils/embed.js');
const config = require('../config.js');
const logger = require('../utils/logger.js');

const commands = {
    serverinfo: {
        name: 'serverinfo',
        description: 'Display information about the server',
        usage: 'serverinfo',
        async execute(message, args) {
            const guild = message.guild;
            
            const embed = new EmbedBuilder()
                .setTitle(`📊 ${guild.name}`)
                .setThumbnail(guild.iconURL({ dynamic: true }))
                .addFields(
                    { name: 'Owner', value: `<@${guild.ownerId}>`, inline: true },
                    { name: 'Members', value: guild.memberCount.toString(), inline: true },
                    { name: 'Created', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:F>`, inline: true },
                    { name: 'Boost Level', value: guild.premiumTier.toString(), inline: true },
                    { name: 'Boost Count', value: guild.premiumSubscriptionCount?.toString() || '0', inline: true },
                    { name: 'Channels', value: guild.channels.cache.size.toString(), inline: true },
                    { name: 'Roles', value: guild.roles.cache.size.toString(), inline: true },
                    { name: 'Emojis', value: guild.emojis.cache.size.toString(), inline: true },
                    { name: 'Region', value: guild.preferredLocale || 'Unknown', inline: true }
                )
                .setColor(config.colors.primary)
                .setFooter({ text: `Server ID: ${guild.id}` });

            message.reply({ embeds: [embed] });
        }
    },

    userinfo: {
        name: 'userinfo',
        description: 'Display information about a user',
        usage: 'userinfo [@user]',
        async execute(message, args) {
            const user = message.mentions.users.first() || message.author;
            const member = message.guild.members.cache.get(user.id);
            
            const embed = new EmbedBuilder()
                .setTitle(`👤 ${user.tag}`)
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .addFields(
                    { name: 'User ID', value: user.id, inline: true },
                    { name: 'Account Created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:F>`, inline: false }
                )
                .setColor(config.colors.primary);

            if (member) {
                embed.addFields(
                    { name: 'Joined Server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:F>`, inline: false },
                    { name: 'Nickname', value: member.nickname || 'None', inline: true },
                    { name: 'Highest Role', value: member.roles.highest.toString(), inline: true },
                    { name: 'Roles Count', value: (member.roles.cache.size - 1).toString(), inline: true }
                );

                if (member.premiumSince) {
                    embed.addFields({
                        name: 'Boosting Since',
                        value: `<t:${Math.floor(member.premiumSinceTimestamp / 1000)}:F>`,
                        inline: false
                    });
                }
            }

            message.reply({ embeds: [embed] });
        }
    },

    avatar: {
        name: 'avatar',
        description: 'Display a user\'s avatar',
        usage: 'avatar [@user]',
        async execute(message, args) {
            const user = message.mentions.users.first() || message.author;
            
            const embed = new EmbedBuilder()
                .setTitle(`${user.tag}'s Avatar`)
                .setImage(user.displayAvatarURL({ dynamic: true, size: 512 }))
                .setColor(config.colors.primary);

            message.reply({ embeds: [embed] });
        }
    },

    ping: {
        name: 'ping',
        description: 'Check the bot\'s latency',
        usage: 'ping',
        async execute(message, args, client) {
            const sent = await message.reply('🏓 Pinging...');
            const latency = sent.createdTimestamp - message.createdTimestamp;
            const apiLatency = Math.round(client.ws.ping);

            const embed = createEmbed(
                '🏓 Pong!',
                `**Bot Latency:** ${latency}ms\n**API Latency:** ${apiLatency}ms`,
                'info'
            );

            sent.edit({ content: '', embeds: [embed] });
        }
    },

    weather: {
        name: 'weather',
        description: 'Get weather information for a city',
        usage: 'weather <city>',
        async execute(message, args) {
            if (!args.length) {
                return message.reply('Please provide a city name!');
            }

            const city = args.join(' ');
            const apiKey = config.apis.weatherKey;

            if (apiKey === 'default_weather_key') {
                return message.reply('Weather API key not configured. Please set WEATHER_API_KEY environment variable.');
            }

            try {
                const fetch = require('node-fetch');
                const response = await fetch(
                    `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${apiKey}&units=metric`
                );

                if (!response.ok) {
                    if (response.status === 404) {
                        return message.reply('City not found! Please check the spelling.');
                    }
                    throw new Error('Weather API request failed');
                }

                const data = await response.json();

                const embed = new EmbedBuilder()
                    .setTitle(`🌤️ Weather in ${data.name}, ${data.sys.country}`)
                    .addFields(
                        { name: 'Temperature', value: `${Math.round(data.main.temp)}°C`, inline: true },
                        { name: 'Feels Like', value: `${Math.round(data.main.feels_like)}°C`, inline: true },
                        { name: 'Humidity', value: `${data.main.humidity}%`, inline: true },
                        { name: 'Description', value: data.weather[0].description, inline: true },
                        { name: 'Wind Speed', value: `${data.wind.speed} m/s`, inline: true },
                        { name: 'Pressure', value: `${data.main.pressure} hPa`, inline: true }
                    )
                    .setColor(config.colors.primary)
                    .setThumbnail(`https://openweathermap.org/img/w/${data.weather[0].icon}.png`);

                message.reply({ embeds: [embed] });
            } catch (error) {
                logger.error('Weather command error:', error);
                message.reply('Failed to fetch weather data. Please try again later.');
            }
        }
    },

    poll: {
        name: 'poll',
        description: 'Create a poll with reactions',
        usage: 'poll <question> | <option1> | <option2> | ...',
        async execute(message, args) {
            if (!args.length) {
                return message.reply('Please provide a question and options separated by |');
            }

            const pollData = args.join(' ').split('|').map(item => item.trim());
            
            if (pollData.length < 3) {
                return message.reply('Please provide at least a question and 2 options separated by |');
            }

            if (pollData.length > 11) {
                return message.reply('Maximum 10 options allowed!');
            }

            const question = pollData[0];
            const options = pollData.slice(1);

            const reactions = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

            const embed = new EmbedBuilder()
                .setTitle('📊 Poll')
                .setDescription(`**${question}**\n\n${options.map((option, index) => 
                    `${reactions[index]} ${option}`
                ).join('\n')}`)
                .setColor(config.colors.primary)
                .setFooter({ text: `Poll by ${message.author.tag}` })
                .setTimestamp();

            const pollMessage = await message.reply({ embeds: [embed] });

            for (let i = 0; i < options.length; i++) {
                await pollMessage.react(reactions[i]);
            }
        }
    },

    remindme: {
        name: 'remindme',
        description: 'Set a reminder',
        usage: 'remindme <time> <message>',
        async execute(message, args) {
            if (args.length < 2) {
                return message.reply('Usage: `remindme <time> <message>`\nExample: `remindme 10m Take a break`');
            }

            const timeStr = args[0].toLowerCase();
            const reminderText = args.slice(1).join(' ');

            // Parse time (e.g., "10m", "1h", "2d")
            const timeMatch = timeStr.match(/^(\d+)([mhd])$/);
            if (!timeMatch) {
                return message.reply('Invalid time format! Use format like: 10m, 1h, 2d');
            }

            const amount = parseInt(timeMatch[1]);
            const unit = timeMatch[2];
            
            let milliseconds;
            switch (unit) {
                case 'm':
                    milliseconds = amount * 60 * 1000;
                    break;
                case 'h':
                    milliseconds = amount * 60 * 60 * 1000;
                    break;
                case 'd':
                    milliseconds = amount * 24 * 60 * 60 * 1000;
                    break;
            }

            if (milliseconds > 7 * 24 * 60 * 60 * 1000) { // 7 days max
                return message.reply('Maximum reminder time is 7 days!');
            }

            const embed = createEmbed(
                'Reminder Set',
                `I'll remind you in ${timeStr}: "${reminderText}"`,
                'success'
            );
            
            message.reply({ embeds: [embed] });

            setTimeout(async () => {
                try {
                    const reminderEmbed = createEmbed(
                        '⏰ Reminder',
                        reminderText,
                        'info'
                    );
                    
                    await message.author.send({ embeds: [reminderEmbed] });
                } catch (error) {
                    // If DM fails, send in the original channel
                    const reminderEmbed = createEmbed(
                        '⏰ Reminder',
                        `${message.author}, you asked me to remind you: ${reminderText}`,
                        'info'
                    );
                    
                    message.channel.send({ embeds: [reminderEmbed] });
                }
            }, milliseconds);
        }
    },

    uptime: {
        name: 'uptime',
        description: 'Display bot uptime',
        usage: 'uptime',
        async execute(message, args, client) {
            const uptime = process.uptime();
            const days = Math.floor(uptime / 86400);
            const hours = Math.floor(uptime / 3600) % 24;
            const minutes = Math.floor(uptime / 60) % 60;
            const seconds = Math.floor(uptime) % 60;

            const uptimeString = `${days}d ${hours}h ${minutes}m ${seconds}s`;

            const embed = createEmbed(
                '⏱️ Bot Uptime',
                `I've been online for: **${uptimeString}**`,
                'info'
            );

            message.reply({ embeds: [embed] });
        }
    },

    invite: {
        name: 'invite',
        description: 'Get the bot invite link',
        usage: 'invite',
        async execute(message, args, client) {
            const permissions = [
                PermissionFlagsBits.SendMessages,
                PermissionFlagsBits.EmbedLinks,
                PermissionFlagsBits.AttachFiles,
                PermissionFlagsBits.ReadMessageHistory,
                PermissionFlagsBits.UseExternalEmojis,
                PermissionFlagsBits.AddReactions,
                PermissionFlagsBits.Connect,
                PermissionFlagsBits.Speak,
                PermissionFlagsBits.KickMembers,
                PermissionFlagsBits.BanMembers,
                PermissionFlagsBits.ModerateMembers,
                PermissionFlagsBits.ManageMessages,
                PermissionFlagsBits.ManageRoles
            ];

            const inviteLink = client.generateInvite({
                scopes: ['bot'],
                permissions: permissions
            });

            const embed = createEmbed(
                '🔗 Invite Me!',
                `[Click here to invite me to your server!](${inviteLink})`,
                'info'
            );

            message.reply({ embeds: [embed] });
        }
    }
};

module.exports = { commands };
