const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const ytdl = require('ytdl-core');
const { createAudioPlayer, createAudioResource, joinVoiceChannel, AudioPlayerStatus, VoiceConnectionStatus } = require('@discordjs/voice');
const { createEmbed } = require('../utils/embed.js');
const logger = require('../utils/logger.js');
const config = require('../config.js');

class MusicQueue {
    constructor(guildId) {
        this.guildId = guildId;
        this.songs = [];
        this.currentSong = null;
        this.player = null;
        this.connection = null;
        this.volume = config.music.defaultVolume;
        this.loop = false;
        this.isPlaying = false;
    }

    addSong(song) {
        this.songs.push(song);
    }

    getQueue() {
        return this.songs;
    }

    clear() {
        this.songs = [];
        this.currentSong = null;
    }

    skip() {
        if (this.player) {
            this.player.stop();
        }
    }

    pause() {
        if (this.player) {
            this.player.pause();
            this.isPlaying = false;
        }
    }

    resume() {
        if (this.player) {
            this.player.unpause();
            this.isPlaying = true;
        }
    }

    setVolume(volume) {
        this.volume = Math.max(0, Math.min(100, volume));
    }

    toggleLoop() {
        this.loop = !this.loop;
        return this.loop;
    }
}

function getQueue(guildId, client) {
    if (!client.musicQueues.has(guildId)) {
        client.musicQueues.set(guildId, new MusicQueue(guildId));
    }
    return client.musicQueues.get(guildId);
}

async function playSong(queue, message) {
    if (queue.songs.length === 0) {
        queue.currentSong = null;
        queue.isPlaying = false;
        
        const embed = createEmbed(
            'Queue Finished',
            'No more songs in the queue.',
            'info'
        );
        message.channel.send({ embeds: [embed] });
        
        // Leave voice channel after 5 minutes of inactivity
        setTimeout(() => {
            if (queue.connection && queue.songs.length === 0) {
                queue.connection.destroy();
                queue.connection = null;
            }
        }, 300000);
        
        return;
    }

    const song = queue.songs.shift();
    queue.currentSong = song;

    try {
        const stream = ytdl(song.url, {
            filter: 'audioonly',
            quality: 'highestaudio',
            highWaterMark: 1 << 25
        });

        const resource = createAudioResource(stream);
        queue.player.play(resource);
        queue.isPlaying = true;

        const embed = createEmbed(
            'Now Playing',
            `🎵 **${song.title}**\nRequested by: ${song.requester}`,
            'success'
        );
        
        message.channel.send({ embeds: [embed] });

        queue.player.once(AudioPlayerStatus.Idle, () => {
            if (queue.loop && queue.currentSong) {
                queue.addSong(queue.currentSong);
            }
            playSong(queue, message);
        });

    } catch (error) {
        logger.error('Error playing song:', error);
        const embed = createEmbed(
            'Playback Error',
            'Failed to play the song. Skipping to next...',
            'error'
        );
        message.channel.send({ embeds: [embed] });
        playSong(queue, message);
    }
}

const commands = {
    play: {
        name: 'play',
        description: 'Play a song from YouTube',
        usage: 'play <YouTube URL or search term>',
        async execute(message, args, client) {
            const voiceChannel = message.member.voice.channel;
            if (!voiceChannel) {
                return message.reply('You need to be in a voice channel to play music!');
            }

            if (!args.length) {
                return message.reply('Please provide a YouTube URL or search term!');
            }

            const query = args.join(' ');
            const queue = getQueue(message.guild.id, client);

            // Check if URL is valid YouTube URL
            let url = query;
            if (!ytdl.validateURL(query)) {
                // For simplicity, we'll require direct YouTube URLs
                // In a full implementation, you'd integrate with YouTube Search API
                return message.reply('Please provide a valid YouTube URL. Search functionality requires YouTube API integration.');
            }

            try {
                const info = await ytdl.getInfo(url);
                const song = {
                    title: info.videoDetails.title,
                    url: url,
                    duration: info.videoDetails.lengthSeconds,
                    requester: message.author.toString(),
                    thumbnail: info.videoDetails.thumbnails[0]?.url
                };

                // Check queue size limit
                if (queue.songs.length >= config.music.maxQueueSize) {
                    return message.reply(`Queue is full! Maximum ${config.music.maxQueueSize} songs allowed.`);
                }

                queue.addSong(song);

                if (!queue.connection) {
                    try {
                        queue.connection = joinVoiceChannel({
                            channelId: voiceChannel.id,
                            guildId: message.guild.id,
                            adapterCreator: message.guild.voiceAdapterCreator
                        });

                        queue.player = createAudioPlayer();
                        queue.connection.subscribe(queue.player);

                        queue.connection.on(VoiceConnectionStatus.Disconnected, () => {
                            queue.clear();
                            queue.connection = null;
                            queue.player = null;
                        });

                    } catch (error) {
                        logger.error('Error joining voice channel:', error);
                        return message.reply('Failed to join the voice channel!');
                    }
                }

                const embed = createEmbed(
                    'Song Added to Queue',
                    `🎵 **${song.title}**\nPosition in queue: ${queue.songs.length}\nRequested by: ${message.author}`,
                    'success'
                );

                message.reply({ embeds: [embed] });

                if (!queue.isPlaying) {
                    playSong(queue, message);
                }

            } catch (error) {
                logger.error('Error adding song to queue:', error);
                message.reply('Failed to add song to queue. Make sure the URL is valid.');
            }
        }
    },

    skip: {
        name: 'skip',
        description: 'Skip the current song',
        usage: 'skip',
        async execute(message, args, client) {
            const queue = getQueue(message.guild.id, client);
            
            if (!queue.isPlaying) {
                return message.reply('Nothing is currently playing!');
            }

            queue.skip();
            
            const embed = createEmbed(
                'Song Skipped',
                'Skipped the current song.',
                'info'
            );
            
            message.reply({ embeds: [embed] });
        }
    },

    pause: {
        name: 'pause',
        description: 'Pause the current song',
        usage: 'pause',
        async execute(message, args, client) {
            const queue = getQueue(message.guild.id, client);
            
            if (!queue.isPlaying) {
                return message.reply('Nothing is currently playing!');
            }

            queue.pause();
            
            const embed = createEmbed(
                'Music Paused',
                'Paused the current song.',
                'info'
            );
            
            message.reply({ embeds: [embed] });
        }
    },

    resume: {
        name: 'resume',
        description: 'Resume the current song',
        usage: 'resume',
        async execute(message, args, client) {
            const queue = getQueue(message.guild.id, client);
            
            if (queue.isPlaying) {
                return message.reply('Music is already playing!');
            }

            if (!queue.player) {
                return message.reply('Nothing to resume!');
            }

            queue.resume();
            
            const embed = createEmbed(
                'Music Resumed',
                'Resumed the current song.',
                'success'
            );
            
            message.reply({ embeds: [embed] });
        }
    },

    stop: {
        name: 'stop',
        description: 'Stop music and clear the queue',
        usage: 'stop',
        async execute(message, args, client) {
            const queue = getQueue(message.guild.id, client);
            
            if (!queue.connection) {
                return message.reply('Not connected to a voice channel!');
            }

            queue.clear();
            if (queue.player) {
                queue.player.stop();
            }
            if (queue.connection) {
                queue.connection.destroy();
                queue.connection = null;
            }

            const embed = createEmbed(
                'Music Stopped',
                'Stopped playing music and cleared the queue.',
                'info'
            );
            
            message.reply({ embeds: [embed] });
        }
    },

    queue: {
        name: 'queue',
        description: 'Display the current music queue',
        usage: 'queue',
        async execute(message, args, client) {
            const queue = getQueue(message.guild.id, client);
            
            if (queue.songs.length === 0 && !queue.currentSong) {
                return message.reply('The queue is empty!');
            }

            const embed = new EmbedBuilder()
                .setTitle('Music Queue')
                .setColor(config.colors.primary);

            if (queue.currentSong) {
                embed.addFields({
                    name: '🎵 Now Playing',
                    value: `**${queue.currentSong.title}**\nRequested by: ${queue.currentSong.requester}`,
                    inline: false
                });
            }

            if (queue.songs.length > 0) {
                const upcoming = queue.songs.slice(0, 10).map((song, index) => 
                    `${index + 1}. **${song.title}** - ${song.requester}`
                ).join('\n');

                embed.addFields({
                    name: '📋 Up Next',
                    value: upcoming,
                    inline: false
                });

                if (queue.songs.length > 10) {
                    embed.setFooter({ text: `... and ${queue.songs.length - 10} more songs` });
                }
            }

            message.reply({ embeds: [embed] });
        }
    },

    volume: {
        name: 'volume',
        description: 'Set the music volume',
        usage: 'volume <1-100>',
        async execute(message, args, client) {
            const queue = getQueue(message.guild.id, client);
            
            if (!args[0]) {
                return message.reply(`Current volume: ${queue.volume}%`);
            }

            const volume = parseInt(args[0]);
            if (isNaN(volume) || volume < 1 || volume > 100) {
                return message.reply('Volume must be between 1 and 100!');
            }

            queue.setVolume(volume);
            
            const embed = createEmbed(
                'Volume Changed',
                `Volume set to ${volume}%`,
                'info'
            );
            
            message.reply({ embeds: [embed] });
        }
    },

    loop: {
        name: 'loop',
        description: 'Toggle loop mode for the current song',
        usage: 'loop',
        async execute(message, args, client) {
            const queue = getQueue(message.guild.id, client);
            
            const isLooping = queue.toggleLoop();
            
            const embed = createEmbed(
                'Loop Mode',
                `Loop mode ${isLooping ? 'enabled' : 'disabled'}`,
                'info'
            );
            
            message.reply({ embeds: [embed] });
        }
    },

    nowplaying: {
        name: 'nowplaying',
        aliases: ['np'],
        description: 'Display the currently playing song',
        usage: 'nowplaying',
        async execute(message, args, client) {
            const queue = getQueue(message.guild.id, client);
            
            if (!queue.currentSong) {
                return message.reply('Nothing is currently playing!');
            }

            const song = queue.currentSong;
            const embed = new EmbedBuilder()
                .setTitle('🎵 Now Playing')
                .setDescription(`**${song.title}**`)
                .addFields(
                    { name: 'Requested by', value: song.requester, inline: true },
                    { name: 'Volume', value: `${queue.volume}%`, inline: true },
                    { name: 'Loop', value: queue.loop ? 'Enabled' : 'Disabled', inline: true }
                )
                .setColor(config.colors.primary);

            if (song.thumbnail) {
                embed.setThumbnail(song.thumbnail);
            }

            message.reply({ embeds: [embed] });
        }
    }
};

module.exports = { commands };
