const { EmbedBuilder } = require('discord.js');
const database = require('../database/database.js');
const { createEmbed } = require('../utils/embed.js');
const config = require('../config.js');
const logger = require('../utils/logger.js');

function calculateLevel(xp) {
    return Math.floor(0.1 * Math.sqrt(xp)) + 1;
}

function calculateXpForLevel(level) {
    return Math.pow((level - 1) * 10, 2);
}

function calculateXpForNextLevel(level) {
    return calculateXpForLevel(level + 1);
}

const commands = {
    level: {
        name: 'level',
        aliases: ['lvl'],
        description: 'Check your or another user\'s level',
        usage: 'level [@user]',
        async execute(message, args) {
            const target = message.mentions.users.first() || message.author;
            
            try {
                await database.createUser(target.id, message.guild.id);
                const userData = await database.getUser(target.id, message.guild.id);
                
                const xp = userData?.xp || 0;
                const currentLevel = calculateLevel(xp);
                const xpForCurrentLevel = calculateXpForLevel(currentLevel);
                const xpForNextLevel = calculateXpForNextLevel(currentLevel);
                const xpProgress = xp - xpForCurrentLevel;
                const xpNeeded = xpForNextLevel - xpForCurrentLevel;
                
                const progressBar = createProgressBar(xpProgress, xpNeeded, 20);
                const percentage = Math.round((xpProgress / xpNeeded) * 100);

                const embed = new EmbedBuilder()
                    .setTitle(`📊 ${target.username}'s Level`)
                    .setThumbnail(target.displayAvatarURL({ dynamic: true }))
                    .addFields(
                        { name: 'Level', value: currentLevel.toString(), inline: true },
                        { name: 'Total XP', value: xp.toLocaleString(), inline: true },
                        { name: 'Progress', value: `${percentage}%`, inline: true },
                        { 
                            name: 'Progress to Next Level', 
                            value: `${progressBar}\n${xpProgress.toLocaleString()}/${xpNeeded.toLocaleString()} XP`, 
                            inline: false 
                        }
                    )
                    .setColor(config.colors.primary);

                message.reply({ embeds: [embed] });
            } catch (error) {
                logger.error('Error fetching level data:', error);
                message.reply('Failed to fetch level data.');
            }
        }
    },

    rank: {
        name: 'rank',
        description: 'Check your server rank',
        usage: 'rank [@user]',
        async execute(message, args) {
            const target = message.mentions.users.first() || message.author;
            
            try {
                await database.createUser(target.id, message.guild.id);
                
                // Get user's rank in the server
                const result = await database.get(`
                    SELECT 
                        user_id,
                        xp,
                        level,
                        RANK() OVER (ORDER BY xp DESC) as rank
                    FROM users 
                    WHERE guild_id = ? AND user_id = ?
                `, [message.guild.id, target.id]);

                if (!result) {
                    return message.reply('User not found in rankings!');
                }

                const currentLevel = calculateLevel(result.xp);
                const xpForCurrentLevel = calculateXpForLevel(currentLevel);
                const xpForNextLevel = calculateXpForNextLevel(currentLevel);
                const xpProgress = result.xp - xpForCurrentLevel;
                const xpNeeded = xpForNextLevel - xpForCurrentLevel;
                
                const progressBar = createProgressBar(xpProgress, xpNeeded, 20);

                const embed = new EmbedBuilder()
                    .setTitle(`🏆 ${target.username}'s Rank`)
                    .setThumbnail(target.displayAvatarURL({ dynamic: true }))
                    .addFields(
                        { name: 'Server Rank', value: `#${result.rank}`, inline: true },
                        { name: 'Level', value: currentLevel.toString(), inline: true },
                        { name: 'Total XP', value: result.xp.toLocaleString(), inline: true },
                        { 
                            name: 'Progress to Next Level', 
                            value: `${progressBar}\n${xpProgress.toLocaleString()}/${xpNeeded.toLocaleString()} XP`, 
                            inline: false 
                        }
                    )
                    .setColor(config.colors.primary);

                message.reply({ embeds: [embed] });
            } catch (error) {
                logger.error('Error fetching rank data:', error);
                message.reply('Failed to fetch rank data.');
            }
        }
    },

    leaderboard: {
        name: 'levels',
        aliases: ['toplevel'],
        description: 'View the server\'s level leaderboard',
        usage: 'levels',
        async execute(message, args) {
            try {
                const topUsers = await database.all(`
                    SELECT user_id, xp, level
                    FROM users 
                    WHERE guild_id = ? 
                    ORDER BY xp DESC 
                    LIMIT 10
                `, [message.guild.id]);

                if (topUsers.length === 0) {
                    return message.reply('No level data found for this server!');
                }

                const embed = new EmbedBuilder()
                    .setTitle(`📈 ${message.guild.name} - Level Leaderboard`)
                    .setColor(config.colors.primary)
                    .setThumbnail(message.guild.iconURL());

                let description = '';
                for (let i = 0; i < topUsers.length; i++) {
                    const user = topUsers[i];
                    const member = message.guild.members.cache.get(user.user_id);
                    const username = member ? member.user.username : 'Unknown User';
                    const level = calculateLevel(user.xp);
                    
                    const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}.`;
                    description += `${medal} **${username}** - Level ${level} (${user.xp.toLocaleString()} XP)\n`;
                }

                embed.setDescription(description);
                message.reply({ embeds: [embed] });
            } catch (error) {
                logger.error('Error fetching level leaderboard:', error);
                message.reply('Failed to fetch level leaderboard.');
            }
        }
    },

    setlevel: {
        name: 'setlevel',
        description: 'Set a user\'s level (Admin only)',
        usage: 'setlevel <@user> <level>',
        async execute(message, args) {
            if (!message.member.permissions.has('Administrator')) {
                return message.reply('You need Administrator permission to use this command!');
            }

            const target = message.mentions.users.first();
            if (!target) {
                return message.reply('Please mention a user!');
            }

            const level = parseInt(args[1]);
            if (!level || level < 1 || level > 1000) {
                return message.reply('Please provide a valid level between 1 and 1000!');
            }

            try {
                await database.createUser(target.id, message.guild.id);
                
                const xp = calculateXpForLevel(level);
                await database.run(
                    'UPDATE users SET xp = ?, level = ? WHERE user_id = ? AND guild_id = ?',
                    [xp, level, target.id, message.guild.id]
                );

                const embed = createEmbed(
                    'Level Set',
                    `Set ${target.username}'s level to **${level}** (${xp.toLocaleString()} XP)`,
                    'success'
                );

                message.reply({ embeds: [embed] });
            } catch (error) {
                logger.error('Error setting level:', error);
                message.reply('Failed to set level.');
            }
        }
    },

    addxp: {
        name: 'addxp',
        description: 'Add XP to a user (Admin only)',
        usage: 'addxp <@user> <amount>',
        async execute(message, args) {
            if (!message.member.permissions.has('Administrator')) {
                return message.reply('You need Administrator permission to use this command!');
            }

            const target = message.mentions.users.first();
            if (!target) {
                return message.reply('Please mention a user!');
            }

            const amount = parseInt(args[1]);
            if (!amount || amount < 1 || amount > 10000) {
                return message.reply('Please provide a valid XP amount between 1 and 10000!');
            }

            try {
                await database.createUser(target.id, message.guild.id);
                
                const oldData = await database.getUser(target.id, message.guild.id);
                const oldLevel = calculateLevel(oldData.xp);
                
                await database.updateUserXP(target.id, message.guild.id, amount);
                
                const newData = await database.getUser(target.id, message.guild.id);
                const newLevel = calculateLevel(newData.xp);

                let response = `Added **${amount}** XP to ${target.username}`;
                
                if (newLevel > oldLevel) {
                    response += `\n🎉 They leveled up to level **${newLevel}**!`;
                }

                const embed = createEmbed('XP Added', response, 'success');
                message.reply({ embeds: [embed] });
            } catch (error) {
                logger.error('Error adding XP:', error);
                message.reply('Failed to add XP.');
            }
        }
    },

    resetlevels: {
        name: 'resetlevels',
        description: 'Reset all levels in the server (Admin only)',
        usage: 'resetlevels',
        async execute(message, args) {
            if (!message.member.permissions.has('Administrator')) {
                return message.reply('You need Administrator permission to use this command!');
            }

            // Confirmation prompt
            const confirmEmbed = createEmbed(
                'Confirm Reset',
                'Are you sure you want to reset ALL level data for this server?\nType `yes` to confirm or `no` to cancel.',
                'warning'
            );

            const confirmMessage = await message.reply({ embeds: [confirmEmbed] });

            try {
                const filter = (m) => m.author.id === message.author.id && ['yes', 'no'].includes(m.content.toLowerCase());
                const collected = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });

                if (!collected.size || collected.first().content.toLowerCase() === 'no') {
                    const cancelEmbed = createEmbed('Reset Cancelled', 'Level reset has been cancelled.', 'info');
                    return confirmMessage.edit({ embeds: [cancelEmbed] });
                }

                await database.run('UPDATE users SET xp = 0, level = 1 WHERE guild_id = ?', [message.guild.id]);

                const successEmbed = createEmbed(
                    'Levels Reset',
                    'All user levels have been reset for this server.',
                    'success'
                );

                confirmMessage.edit({ embeds: [successEmbed] });
            } catch (error) {
                logger.error('Error resetting levels:', error);
                message.reply('Failed to reset levels.');
            }
        }
    }
};

function createProgressBar(current, max, length = 20) {
    const percentage = current / max;
    const progress = Math.round(length * percentage);
    const empty = length - progress;
    
    const progressChar = '█';
    const emptyChar = '░';
    
    return progressChar.repeat(progress) + emptyChar.repeat(empty);
}

module.exports = { commands };
