const { EmbedBuilder } = require('discord.js');
const { createEmbed } = require('../utils/embed.js');
const config = require('../config.js');

const eightBallResponses = [
    'It is certain',
    'It is decidedly so',
    'Without a doubt',
    'Yes definitely',
    'You may rely on it',
    'As I see it, yes',
    'Most likely',
    'Outlook good',
    'Yes',
    'Signs point to yes',
    'Reply hazy, try again',
    'Ask again later',
    'Better not tell you now',
    'Cannot predict now',
    'Concentrate and ask again',
    "Don't count on it",
    'My reply is no',
    'My sources say no',
    'Outlook not so good',
    'Very doubtful'
];

const jokes = [
    "Why don't scientists trust atoms? Because they make up everything!",
    "Why did the scarecrow win an award? He was outstanding in his field!",
    "Why don't eggs tell jokes? They'd crack each other up!",
    "What do you call a fake noodle? An impasta!",
    "Why did the math book look so sad? Because it had too many problems!",
    "What do you call a bear with no teeth? A gummy bear!",
    "Why don't programmers like nature? It has too many bugs!",
    "What's the best thing about Switzerland? I don't know, but the flag is a big plus!",
    "Why did the coffee file a police report? It got mugged!",
    "What do you call a dinosaur that crashes his car? Tyrannosaurus Wrecks!"
];

const commands = {
    '8ball': {
        name: '8ball',
        description: 'Ask the magic 8-ball a question',
        usage: '8ball <question>',
        async execute(message, args) {
            if (!args.length) {
                return message.reply('Please ask a question for the magic 8-ball!');
            }

            const question = args.join(' ');
            const response = eightBallResponses[Math.floor(Math.random() * eightBallResponses.length)];

            const embed = new EmbedBuilder()
                .setTitle('🎱 Magic 8-Ball')
                .addFields(
                    { name: 'Question', value: question, inline: false },
                    { name: 'Answer', value: response, inline: false }
                )
                .setColor(config.colors.primary)
                .setFooter({ text: `Asked by ${message.author.tag}` });

            message.reply({ embeds: [embed] });
        }
    },

    roll: {
        name: 'roll',
        aliases: ['dice'],
        description: 'Roll dice',
        usage: 'roll [number of sides] [number of dice]',
        async execute(message, args) {
            let sides = 6;
            let count = 1;

            if (args[0]) {
                sides = parseInt(args[0]);
                if (isNaN(sides) || sides < 2 || sides > 100) {
                    return message.reply('Number of sides must be between 2 and 100!');
                }
            }

            if (args[1]) {
                count = parseInt(args[1]);
                if (isNaN(count) || count < 1 || count > 10) {
                    return message.reply('Number of dice must be between 1 and 10!');
                }
            }

            const rolls = [];
            let total = 0;

            for (let i = 0; i < count; i++) {
                const roll = Math.floor(Math.random() * sides) + 1;
                rolls.push(roll);
                total += roll;
            }

            const embed = new EmbedBuilder()
                .setTitle('🎲 Dice Roll')
                .addFields(
                    { name: 'Dice', value: `${count}d${sides}`, inline: true },
                    { name: 'Rolls', value: rolls.join(', '), inline: true },
                    { name: 'Total', value: total.toString(), inline: true }
                )
                .setColor(config.colors.primary)
                .setFooter({ text: `Rolled by ${message.author.tag}` });

            message.reply({ embeds: [embed] });
        }
    },

    coinflip: {
        name: 'coinflip',
        aliases: ['flip'],
        description: 'Flip a coin',
        usage: 'coinflip',
        async execute(message, args) {
            const result = Math.random() < 0.5 ? 'Heads' : 'Tails';
            const emoji = result === 'Heads' ? '🪙' : '🥉';

            const embed = createEmbed(
                '🪙 Coin Flip',
                `${emoji} **${result}**`,
                'info'
            );

            message.reply({ embeds: [embed] });
        }
    },

    joke: {
        name: 'joke',
        description: 'Get a random joke',
        usage: 'joke',
        async execute(message, args) {
            const joke = jokes[Math.floor(Math.random() * jokes.length)];

            const embed = createEmbed(
                '😂 Random Joke',
                joke,
                'info'
            );

            message.reply({ embeds: [embed] });
        }
    },

    rps: {
        name: 'rps',
        description: 'Play rock paper scissors',
        usage: 'rps <rock/paper/scissors>',
        async execute(message, args) {
            if (!args[0]) {
                return message.reply('Please choose rock, paper, or scissors!');
            }

            const choices = ['rock', 'paper', 'scissors'];
            const userChoice = args[0].toLowerCase();

            if (!choices.includes(userChoice)) {
                return message.reply('Please choose rock, paper, or scissors!');
            }

            const botChoice = choices[Math.floor(Math.random() * choices.length)];
            
            let result;
            if (userChoice === botChoice) {
                result = "It's a tie!";
            } else if (
                (userChoice === 'rock' && botChoice === 'scissors') ||
                (userChoice === 'paper' && botChoice === 'rock') ||
                (userChoice === 'scissors' && botChoice === 'paper')
            ) {
                result = 'You win!';
            } else {
                result = 'I win!';
            }

            const emojis = {
                rock: '🪨',
                paper: '📄',
                scissors: '✂️'
            };

            const embed = new EmbedBuilder()
                .setTitle('🎮 Rock Paper Scissors')
                .addFields(
                    { name: 'Your Choice', value: `${emojis[userChoice]} ${userChoice}`, inline: true },
                    { name: 'My Choice', value: `${emojis[botChoice]} ${botChoice}`, inline: true },
                    { name: 'Result', value: result, inline: false }
                )
                .setColor(config.colors.primary)
                .setFooter({ text: `Played by ${message.author.tag}` });

            message.reply({ embeds: [embed] });
        }
    },

    choose: {
        name: 'choose',
        description: 'Choose between multiple options',
        usage: 'choose <option1> | <option2> | ...',
        async execute(message, args) {
            if (!args.length) {
                return message.reply('Please provide options separated by |');
            }

            const options = args.join(' ').split('|').map(option => option.trim());
            
            if (options.length < 2) {
                return message.reply('Please provide at least 2 options separated by |');
            }

            const choice = options[Math.floor(Math.random() * options.length)];

            const embed = createEmbed(
                '🤔 Choice Made',
                `I choose: **${choice}**`,
                'info'
            );

            message.reply({ embeds: [embed] });
        }
    },

    say: {
        name: 'say',
        description: 'Make the bot say something',
        usage: 'say <message>',
        async execute(message, args) {
            if (!args.length) {
                return message.reply('Please provide a message to say!');
            }

            const text = args.join(' ');
            
            // Basic filter for inappropriate content
            const blacklist = ['@everyone', '@here'];
            if (blacklist.some(word => text.toLowerCase().includes(word.toLowerCase()))) {
                return message.reply('I cannot say that!');
            }

            await message.delete().catch(() => {});
            message.channel.send(text);
        }
    },

    reverse: {
        name: 'reverse',
        description: 'Reverse a message',
        usage: 'reverse <message>',
        async execute(message, args) {
            if (!args.length) {
                return message.reply('Please provide a message to reverse!');
            }

            const text = args.join(' ');
            const reversed = text.split('').reverse().join('');

            const embed = createEmbed(
                '🔄 Reversed Text',
                `**Original:** ${text}\n**Reversed:** ${reversed}`,
                'info'
            );

            message.reply({ embeds: [embed] });
        }
    },

    ascii: {
        name: 'ascii',
        description: 'Convert text to ASCII art (simple)',
        usage: 'ascii <text>',
        async execute(message, args) {
            if (!args.length) {
                return message.reply('Please provide text to convert!');
            }

            const text = args.join(' ').toLowerCase();
            
            if (text.length > 10) {
                return message.reply('Text must be 10 characters or less!');
            }

            // Simple ASCII art mapping (very basic)
            const ascii = {
                'a': '█▀█\n█▀█\n▀ █',
                'b': '██▄\n██▄\n██▄',
                'c': '▄▀█\n█▄▄\n▀▀▀',
                'hello': '█ █ █▀▀ █   █   ▄▀█\n█▀█ █▄▄ █▄▄ █▄▄ █▄█'
            };

            const result = ascii[text] || 'ASCII art not available for this text';

            const embed = new EmbedBuilder()
                .setTitle('🎨 ASCII Art')
                .setDescription(`\`\`\`\n${result}\n\`\`\``)
                .setColor(config.colors.primary);

            message.reply({ embeds: [embed] });
        }
    }
};

module.exports = { commands };
