const { EmbedBuilder } = require('discord.js');
const { createEmbed } = require('../utils/embed.js');
const config = require('../config.js');

const commands = {
    help: {
        name: 'help',
        description: 'Display help information for commands',
        usage: 'help [command]',
        async execute(message, args, client) {
            if (args[0]) {
                // Show help for specific command
                const commandName = args[0].toLowerCase();
                const command = client.commands.get(commandName) || 
                               client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));

                if (!command) {
                    return message.reply(`Command \`${commandName}\` not found!`);
                }

                const embed = new EmbedBuilder()
                    .setTitle(`📖 Help: ${command.name}`)
                    .setDescription(command.description || 'No description available')
                    .addFields(
                        { name: 'Usage', value: `\`${config.prefix}${command.usage || command.name}\``, inline: true }
                    )
                    .setColor(config.colors.info);

                if (command.aliases && command.aliases.length > 0) {
                    embed.addFields(
                        { name: 'Aliases', value: command.aliases.map(alias => `\`${alias}\``).join(', '), inline: true }
                    );
                }

                return message.reply({ embeds: [embed] });
            }

            // Show general help with all commands
            const embed = new EmbedBuilder()
                .setTitle('🤖 Bot Commands')
                .setDescription(`Use \`${config.prefix}help <command>\` for detailed information about a specific command.`)
                .setColor(config.colors.primary)
                .setThumbnail(client.user.displayAvatarURL());

            // Group commands by category
            const categories = {
                '🛡️ Moderation': ['kick', 'ban', 'unban', 'warn', 'warnings', 'mute', 'unmute', 'clear'],
                '🎵 Music': ['play', 'skip', 'pause', 'resume', 'stop', 'queue', 'volume', 'loop', 'nowplaying'],
                '💰 Economy': ['balance', 'daily', 'pay', 'work', 'gamble', 'leaderboard', 'shop', 'buy'],
                '📈 Leveling': ['level', 'rank', 'levels', 'setlevel', 'addxp', 'resetlevels'],
                '🔧 Utility': ['serverinfo', 'userinfo', 'avatar', 'ping', 'weather', 'poll', 'remindme', 'uptime', 'invite'],
                '🎮 Fun': ['8ball', 'roll', 'coinflip', 'joke', 'rps', 'choose', 'say', 'reverse', 'ascii'],
                '❓ Help': ['help']
            };

            for (const [category, commandList] of Object.entries(categories)) {
                const availableCommands = commandList.filter(cmdName => client.commands.has(cmdName));
                if (availableCommands.length > 0) {
                    embed.addFields({
                        name: category,
                        value: availableCommands.map(cmd => `\`${cmd}\``).join(', '),
                        inline: false
                    });
                }
            }

            embed.setFooter({ 
                text: `Total Commands: ${client.commands.size} | Prefix: ${config.prefix}` 
            });

            message.reply({ embeds: [embed] });
        }
    }
};

module.exports = { commands };