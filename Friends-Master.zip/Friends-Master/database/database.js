const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');
const config = require('../config.js');
const logger = require('../utils/logger.js');

class Database {
    constructor() {
        this.db = null;
    }

    async initialize() {
        return new Promise((resolve, reject) => {
            this.db = new sqlite3.Database(config.database.path, (err) => {
                if (err) {
                    reject(err);
                    return;
                }
                logger.info('Connected to SQLite database');
                this.createTables().then(resolve).catch(reject);
            });
        });
    }

    async createTables() {
        const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
        const statements = schema.split(';').filter(stmt => stmt.trim());
        
        for (const statement of statements) {
            if (statement.trim()) {
                await this.run(statement);
            }
        }
    }

    run(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.run(sql, params, function(err) {
                if (err) {
                    reject(err);
                } else {
                    resolve({ id: this.lastID, changes: this.changes });
                }
            });
        });
    }

    get(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.get(sql, params, (err, row) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(row);
                }
            });
        });
    }

    all(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.all(sql, params, (err, rows) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(rows);
                }
            });
        });
    }

    close() {
        return new Promise((resolve, reject) => {
            this.db.close((err) => {
                if (err) {
                    reject(err);
                } else {
                    resolve();
                }
            });
        });
    }

    // User economy methods
    async getUser(userId, guildId) {
        return await this.get(
            'SELECT * FROM users WHERE user_id = ? AND guild_id = ?',
            [userId, guildId]
        );
    }

    async createUser(userId, guildId) {
        return await this.run(
            'INSERT OR IGNORE INTO users (user_id, guild_id, balance, xp, level, last_daily) VALUES (?, ?, 0, 0, 1, 0)',
            [userId, guildId]
        );
    }

    async updateUserBalance(userId, guildId, amount) {
        await this.createUser(userId, guildId);
        return await this.run(
            'UPDATE users SET balance = balance + ? WHERE user_id = ? AND guild_id = ?',
            [amount, userId, guildId]
        );
    }

    async updateUserXP(userId, guildId, xp) {
        await this.createUser(userId, guildId);
        return await this.run(
            'UPDATE users SET xp = xp + ? WHERE user_id = ? AND guild_id = ?',
            [xp, userId, guildId]
        );
    }

    async updateUserLevel(userId, guildId, level) {
        return await this.run(
            'UPDATE users SET level = ? WHERE user_id = ? AND guild_id = ?',
            [level, userId, guildId]
        );
    }

    async setLastDaily(userId, guildId, timestamp) {
        return await this.run(
            'UPDATE users SET last_daily = ? WHERE user_id = ? AND guild_id = ?',
            [timestamp, userId, guildId]
        );
    }

    // Warning system methods
    async addWarning(userId, guildId, moderatorId, reason) {
        return await this.run(
            'INSERT INTO warnings (user_id, guild_id, moderator_id, reason, timestamp) VALUES (?, ?, ?, ?, ?)',
            [userId, guildId, moderatorId, reason, Date.now()]
        );
    }

    async getWarnings(userId, guildId) {
        return await this.all(
            'SELECT * FROM warnings WHERE user_id = ? AND guild_id = ? ORDER BY timestamp DESC',
            [userId, guildId]
        );
    }

    // Guild settings methods
    async getGuildSettings(guildId) {
        return await this.get(
            'SELECT * FROM guild_settings WHERE guild_id = ?',
            [guildId]
        );
    }

    async setGuildPrefix(guildId, prefix) {
        return await this.run(
            'INSERT OR REPLACE INTO guild_settings (guild_id, prefix) VALUES (?, ?)',
            [guildId, prefix]
        );
    }
}

const database = new Database();
module.exports = database;
