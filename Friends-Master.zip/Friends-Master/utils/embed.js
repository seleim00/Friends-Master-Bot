const { EmbedBuilder } = require('discord.js');
const config = require('../config.js');

/**
 * Create a standardized embed with consistent styling
 * @param {string} title - The embed title
 * @param {string} description - The embed description
 * @param {string} type - The embed type (success, error, warning, info, primary)
 * @param {object} options - Additional embed options
 * @returns {EmbedBuilder} - The created embed
 */
function createEmbed(title, description, type = 'primary', options = {}) {
    const embed = new EmbedBuilder()
        .setTitle(title)
        .setDescription(description)
        .setTimestamp();

    // Set color based on type
    const colors = {
        success: config.colors.success,
        error: config.colors.error,
        warning: config.colors.warning,
        info: config.colors.info,
        primary: config.colors.primary
    };

    embed.setColor(colors[type] || colors.primary);

    // Add optional fields
    if (options.fields) {
        embed.addFields(options.fields);
    }

    if (options.thumbnail) {
        embed.setThumbnail(options.thumbnail);
    }

    if (options.image) {
        embed.setImage(options.image);
    }

    if (options.footer) {
        embed.setFooter(options.footer);
    }

    if (options.author) {
        embed.setAuthor(options.author);
    }

    if (options.url) {
        embed.setURL(options.url);
    }

    return embed;
}

/**
 * Create an error embed with consistent styling
 * @param {string} title - The error title
 * @param {string} description - The error description
 * @param {object} options - Additional embed options
 * @returns {EmbedBuilder} - The created error embed
 */
function createErrorEmbed(title, description, options = {}) {
    return createEmbed(title, description, 'error', {
        ...options,
        footer: options.footer || { text: '❌ Error' }
    });
}

/**
 * Create a success embed with consistent styling
 * @param {string} title - The success title
 * @param {string} description - The success description
 * @param {object} options - Additional embed options
 * @returns {EmbedBuilder} - The created success embed
 */
function createSuccessEmbed(title, description, options = {}) {
    return createEmbed(title, description, 'success', {
        ...options,
        footer: options.footer || { text: '✅ Success' }
    });
}

/**
 * Create a warning embed with consistent styling
 * @param {string} title - The warning title
 * @param {string} description - The warning description
 * @param {object} options - Additional embed options
 * @returns {EmbedBuilder} - The created warning embed
 */
function createWarningEmbed(title, description, options = {}) {
    return createEmbed(title, description, 'warning', {
        ...options,
        footer: options.footer || { text: '⚠️ Warning' }
    });
}

/**
 * Create an info embed with consistent styling
 * @param {string} title - The info title
 * @param {string} description - The info description
 * @param {object} options - Additional embed options
 * @returns {EmbedBuilder} - The created info embed
 */
function createInfoEmbed(title, description, options = {}) {
    return createEmbed(title, description, 'info', {
        ...options,
        footer: options.footer || { text: 'ℹ️ Information' }
    });
}

/**
 * Create a help embed for commands
 * @param {object} command - The command object
 * @param {string} prefix - The server prefix
 * @returns {EmbedBuilder} - The created help embed
 */
function createHelpEmbed(command, prefix) {
    const embed = createEmbed(
        `📖 Help: ${command.name}`,
        command.description || 'No description available',
        'info'
    );

    embed.addFields(
        { name: 'Usage', value: `\`${prefix}${command.usage || command.name}\``, inline: true }
    );

    if (command.aliases && command.aliases.length > 0) {
        embed.addFields(
            { name: 'Aliases', value: command.aliases.map(alias => `\`${alias}\``).join(', '), inline: true }
        );
    }

    if (command.permissions && command.permissions.length > 0) {
        const { formatPermissions } = require('./permissions.js');
        embed.addFields(
            { name: 'Required Permissions', value: formatPermissions(command.permissions).join(', '), inline: false }
        );
    }

    return embed;
}

/**
 * Create a paginated embed list
 * @param {Array} items - Array of items to display
 * @param {number} page - Current page number (0-indexed)
 * @param {number} itemsPerPage - Items per page
 * @param {string} title - Embed title
 * @param {function} formatter - Function to format each item
 * @returns {EmbedBuilder} - The created paginated embed
 */
function createPaginatedEmbed(items, page = 0, itemsPerPage = 10, title = 'List', formatter = (item) => item.toString()) {
    const totalPages = Math.ceil(items.length / itemsPerPage);
    const startIndex = page * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const pageItems = items.slice(startIndex, endIndex);

    const embed = createEmbed(
        title,
        pageItems.length > 0 ? pageItems.map(formatter).join('\n') : 'No items to display',
        'primary'
    );

    if (totalPages > 1) {
        embed.setFooter({ 
            text: `Page ${page + 1} of ${totalPages} | ${items.length} total items` 
        });
    }

    return embed;
}

/**
 * Create an embed for displaying user statistics
 * @param {User} user - Discord user object
 * @param {object} stats - User statistics
 * @returns {EmbedBuilder} - The created stats embed
 */
function createStatsEmbed(user, stats) {
    const embed = createEmbed(
        `📊 ${user.username}'s Statistics`,
        'Here are your server statistics',
        'primary'
    );

    embed.setThumbnail(user.displayAvatarURL({ dynamic: true }));

    if (stats.level !== undefined) {
        embed.addFields(
            { name: 'Level', value: stats.level.toString(), inline: true },
            { name: 'XP', value: stats.xp?.toLocaleString() || '0', inline: true },
            { name: 'Rank', value: stats.rank ? `#${stats.rank}` : 'Unranked', inline: true }
        );
    }

    if (stats.balance !== undefined) {
        embed.addFields(
            { name: 'Balance', value: `${stats.balance.toLocaleString()} ${config.economy.currencyName}`, inline: true }
        );
    }

    if (stats.commandsUsed) {
        embed.addFields(
            { name: 'Commands Used', value: stats.commandsUsed.toString(), inline: true }
        );
    }

    if (stats.joinedAt) {
        embed.addFields(
            { name: 'Joined Server', value: `<t:${Math.floor(stats.joinedAt / 1000)}:R>`, inline: true }
        );
    }

    return embed;
}

/**
 * Create an embed for displaying server information
 * @param {Guild} guild - Discord guild object
 * @returns {EmbedBuilder} - The created server info embed
 */
function createServerInfoEmbed(guild) {
    const embed = createEmbed(
        `📊 ${guild.name}`,
        'Server Information',
        'primary'
    );

    if (guild.iconURL()) {
        embed.setThumbnail(guild.iconURL({ dynamic: true }));
    }

    embed.addFields(
        { name: 'Owner', value: `<@${guild.ownerId}>`, inline: true },
        { name: 'Members', value: guild.memberCount.toString(), inline: true },
        { name: 'Created', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:F>`, inline: true },
        { name: 'Boost Level', value: guild.premiumTier.toString(), inline: true },
        { name: 'Boost Count', value: guild.premiumSubscriptionCount?.toString() || '0', inline: true },
        { name: 'Channels', value: guild.channels.cache.size.toString(), inline: true }
    );

    embed.setFooter({ text: `Server ID: ${guild.id}` });

    return embed;
}

module.exports = {
    createEmbed,
    createErrorEmbed,
    createSuccessEmbed,
    createWarningEmbed,
    createInfoEmbed,
    createHelpEmbed,
    createPaginatedEmbed,
    createStatsEmbed,
    createServerInfoEmbed
};
