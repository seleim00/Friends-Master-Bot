const config = require('../config.js');

class RateLimiter {
    constructor() {
        this.userCooldowns = new Map();
        this.globalCooldowns = new Map();
    }

    /**
     * Check if a user is rate limited for a specific command
     * @param {string} userId - The user ID
     * @param {string} commandName - The command name
     * @returns {boolean} - Whether the user is rate limited
     */
    isRateLimited(userId, commandName) {
        const now = Date.now();
        const cooldownKey = `${userId}-${commandName}`;
        
        // Check command-specific cooldown
        if (this.userCooldowns.has(cooldownKey)) {
            const expirationTime = this.userCooldowns.get(cooldownKey);
            if (now < expirationTime) {
                return true;
            }
        }

        // Check global user cooldown
        if (this.globalCooldowns.has(userId)) {
            const userData = this.globalCooldowns.get(userId);
            
            // Clean up old timestamps
            userData.timestamps = userData.timestamps.filter(
                timestamp => now - timestamp < 60000 // Keep last minute
            );

            // Check if user exceeded max commands per minute
            if (userData.timestamps.length >= config.rateLimiting.maxCommandsPerMinute) {
                return true;
            }
        }

        // Set cooldowns
        this.userCooldowns.set(cooldownKey, now + config.rateLimiting.commandCooldown);
        
        // Update global cooldown
        if (!this.globalCooldowns.has(userId)) {
            this.globalCooldowns.set(userId, { timestamps: [] });
        }
        this.globalCooldowns.get(userId).timestamps.push(now);

        return false;
    }

    /**
     * Get remaining cooldown time for a user and command
     * @param {string} userId - The user ID
     * @param {string} commandName - The command name
     * @returns {number} - Remaining cooldown time in milliseconds
     */
    getRemainingCooldown(userId, commandName) {
        const now = Date.now();
        const cooldownKey = `${userId}-${commandName}`;
        
        if (this.userCooldowns.has(cooldownKey)) {
            const expirationTime = this.userCooldowns.get(cooldownKey);
            if (now < expirationTime) {
                return expirationTime - now;
            }
        }

        return 0;
    }

    /**
     * Clear cooldowns for a user
     * @param {string} userId - The user ID
     */
    clearUserCooldowns(userId) {
        // Remove command-specific cooldowns
        for (const [key] of this.userCooldowns) {
            if (key.startsWith(userId)) {
                this.userCooldowns.delete(key);
            }
        }

        // Remove global cooldown
        this.globalCooldowns.delete(userId);
    }

    /**
     * Clear all expired cooldowns
     */
    cleanup() {
        const now = Date.now();

        // Clean up command cooldowns
        for (const [key, expirationTime] of this.userCooldowns) {
            if (now >= expirationTime) {
                this.userCooldowns.delete(key);
            }
        }

        // Clean up global cooldowns
        for (const [userId, userData] of this.globalCooldowns) {
            userData.timestamps = userData.timestamps.filter(
                timestamp => now - timestamp < 60000
            );

            if (userData.timestamps.length === 0) {
                this.globalCooldowns.delete(userId);
            }
        }
    }

    /**
     * Get rate limit status for a user
     * @param {string} userId - The user ID
     * @returns {object} - Rate limit status
     */
    getStatus(userId) {
        const now = Date.now();
        const userData = this.globalCooldowns.get(userId);
        
        if (!userData) {
            return {
                commandsUsed: 0,
                maxCommands: config.rateLimiting.maxCommandsPerMinute,
                resetTime: now + 60000
            };
        }

        // Clean up old timestamps
        userData.timestamps = userData.timestamps.filter(
            timestamp => now - timestamp < 60000
        );

        const oldestTimestamp = userData.timestamps[0] || now;
        
        return {
            commandsUsed: userData.timestamps.length,
            maxCommands: config.rateLimiting.maxCommandsPerMinute,
            resetTime: oldestTimestamp + 60000
        };
    }

    /**
     * Set a custom cooldown for a user and command
     * @param {string} userId - The user ID
     * @param {string} commandName - The command name
     * @param {number} duration - Cooldown duration in milliseconds
     */
    setCustomCooldown(userId, commandName, duration) {
        const cooldownKey = `${userId}-${commandName}`;
        this.userCooldowns.set(cooldownKey, Date.now() + duration);
    }
}

const rateLimiter = new RateLimiter();

// Clean up expired cooldowns every 5 minutes
setInterval(() => {
    rateLimiter.cleanup();
}, 5 * 60 * 1000);

module.exports = {
    isRateLimited: (userId, commandName) => rateLimiter.isRateLimited(userId, commandName),
    getRemainingCooldown: (userId, commandName) => rateLimiter.getRemainingCooldown(userId, commandName),
    clearUserCooldowns: (userId) => rateLimiter.clearUserCooldowns(userId),
    getStatus: (userId) => rateLimiter.getStatus(userId),
    setCustomCooldown: (userId, commandName, duration) => rateLimiter.setCustomCooldown(userId, commandName, duration)
};
