const { PermissionFlagsBits } = require('discord.js');

/**
 * Check if a member has the required permissions
 * @param {GuildMember} member - The guild member to check
 * @param {Array} requiredPermissions - Array of permission flags
 * @returns {boolean} - Whether the member has all required permissions
 */
function checkPermissions(member, requiredPermissions = []) {
    if (!member || !member.permissions) {
        return false;
    }

    // Server owner bypasses all permission checks
    if (member.guild.ownerId === member.id) {
        return true;
    }

    // Administrator permission bypasses most checks
    if (member.permissions.has(PermissionFlagsBits.Administrator)) {
        return true;
    }

    // Check if member has all required permissions
    return requiredPermissions.every(permission => 
        member.permissions.has(permission)
    );
}

/**
 * Check if the bot has the required permissions in a channel
 * @param {GuildChannel} channel - The channel to check permissions in
 * @param {Array} requiredPermissions - Array of permission flags
 * @returns {boolean} - Whether the bot has all required permissions
 */
function checkBotPermissions(channel, requiredPermissions = []) {
    if (!channel || !channel.guild) {
        return false;
    }

    const botMember = channel.guild.members.me;
    if (!botMember) {
        return false;
    }

    const permissions = channel.permissionsFor(botMember);
    if (!permissions) {
        return false;
    }

    return requiredPermissions.every(permission => 
        permissions.has(permission)
    );
}

/**
 * Check if a member can moderate another member
 * @param {GuildMember} moderator - The member trying to moderate
 * @param {GuildMember} target - The member being moderated
 * @returns {boolean} - Whether the moderator can moderate the target
 */
function canModerate(moderator, target) {
    if (!moderator || !target) {
        return false;
    }

    // Can't moderate yourself
    if (moderator.id === target.id) {
        return false;
    }

    // Can't moderate server owner
    if (target.guild.ownerId === target.id) {
        return false;
    }

    // Server owner can moderate anyone
    if (moderator.guild.ownerId === moderator.id) {
        return true;
    }

    // Can't moderate someone with higher or equal role
    if (moderator.roles.highest.position <= target.roles.highest.position) {
        return false;
    }

    return true;
}

/**
 * Check if the bot can moderate a member
 * @param {GuildMember} target - The member to be moderated
 * @returns {boolean} - Whether the bot can moderate the target
 */
function canBotModerate(target) {
    if (!target || !target.guild) {
        return false;
    }

    const botMember = target.guild.members.me;
    if (!botMember) {
        return false;
    }

    // Can't moderate server owner
    if (target.guild.ownerId === target.id) {
        return false;
    }

    // Can't moderate someone with higher or equal role
    if (botMember.roles.highest.position <= target.roles.highest.position) {
        return false;
    }

    return true;
}

/**
 * Get missing permissions for a member
 * @param {GuildMember} member - The guild member to check
 * @param {Array} requiredPermissions - Array of permission flags
 * @returns {Array} - Array of missing permission names
 */
function getMissingPermissions(member, requiredPermissions = []) {
    if (!member || !member.permissions) {
        return requiredPermissions.map(perm => perm);
    }

    if (member.permissions.has(PermissionFlagsBits.Administrator)) {
        return [];
    }

    return requiredPermissions.filter(permission => 
        !member.permissions.has(permission)
    );
}

/**
 * Format permission names for display
 * @param {Array} permissions - Array of permission flags
 * @returns {Array} - Array of formatted permission names
 */
function formatPermissions(permissions) {
    const permissionNames = {
        [PermissionFlagsBits.Administrator]: 'Administrator',
        [PermissionFlagsBits.ManageGuild]: 'Manage Server',
        [PermissionFlagsBits.ManageRoles]: 'Manage Roles',
        [PermissionFlagsBits.ManageChannels]: 'Manage Channels',
        [PermissionFlagsBits.KickMembers]: 'Kick Members',
        [PermissionFlagsBits.BanMembers]: 'Ban Members',
        [PermissionFlagsBits.ModerateMembers]: 'Moderate Members',
        [PermissionFlagsBits.ManageMessages]: 'Manage Messages',
        [PermissionFlagsBits.SendMessages]: 'Send Messages',
        [PermissionFlagsBits.EmbedLinks]: 'Embed Links',
        [PermissionFlagsBits.AttachFiles]: 'Attach Files',
        [PermissionFlagsBits.ReadMessageHistory]: 'Read Message History',
        [PermissionFlagsBits.UseExternalEmojis]: 'Use External Emojis',
        [PermissionFlagsBits.AddReactions]: 'Add Reactions',
        [PermissionFlagsBits.Connect]: 'Connect to Voice',
        [PermissionFlagsBits.Speak]: 'Speak in Voice',
        [PermissionFlagsBits.ViewChannel]: 'View Channel'
    };

    return permissions.map(perm => permissionNames[perm] || 'Unknown Permission');
}

module.exports = {
    checkPermissions,
    checkBotPermissions,
    canModerate,
    canBotModerate,
    getMissingPermissions,
    formatPermissions
};
