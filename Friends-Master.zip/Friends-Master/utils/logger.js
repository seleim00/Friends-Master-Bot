const fs = require('fs');
const path = require('path');

class Logger {
    constructor() {
        this.logDir = './logs';
        this.ensureLogDirectory();
    }

    ensureLogDirectory() {
        if (!fs.existsSync(this.logDir)) {
            fs.mkdirSync(this.logDir, { recursive: true });
        }
    }

    formatMessage(level, message) {
        const timestamp = new Date().toISOString();
        return `[${timestamp}] [${level.toUpperCase()}] ${message}`;
    }

    writeToFile(level, message) {
        const today = new Date().toISOString().split('T')[0];
        const filename = `${today}.log`;
        const filepath = path.join(this.logDir, filename);
        
        const formattedMessage = this.formatMessage(level, message);
        
        fs.appendFile(filepath, formattedMessage + '\n', (err) => {
            if (err) {
                console.error('Failed to write to log file:', err);
            }
        });
    }

    log(level, message, ...args) {
        const fullMessage = args.length > 0 
            ? `${message} ${args.map(arg => typeof arg === 'object' ? JSON.stringify(arg) : arg).join(' ')}`
            : message;
        
        // Console output with colors
        const colors = {
            info: '\x1b[36m',     // Cyan
            warn: '\x1b[33m',     // Yellow
            error: '\x1b[31m',    // Red
            debug: '\x1b[35m',    // Magenta
            success: '\x1b[32m'   // Green
        };
        
        const reset = '\x1b[0m';
        const color = colors[level] || '';
        
        console.log(`${color}${this.formatMessage(level, fullMessage)}${reset}`);
        
        // Write to file
        this.writeToFile(level, fullMessage);
    }

    info(message, ...args) {
        this.log('info', message, ...args);
    }

    warn(message, ...args) {
        this.log('warn', message, ...args);
    }

    error(message, ...args) {
        this.log('error', message, ...args);
    }

    debug(message, ...args) {
        this.log('debug', message, ...args);
    }

    success(message, ...args) {
        this.log('success', message, ...args);
    }

    // Clean up old log files (keep last 30 days)
    cleanupOldLogs() {
        try {
            const files = fs.readdirSync(this.logDir);
            const thirtyDaysAgo = new Date();
            thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

            files.forEach(file => {
                if (file.endsWith('.log')) {
                    const fileDate = new Date(file.replace('.log', ''));
                    if (fileDate < thirtyDaysAgo) {
                        fs.unlinkSync(path.join(this.logDir, file));
                        this.info(`Cleaned up old log file: ${file}`);
                    }
                }
            });
        } catch (error) {
            this.error('Error cleaning up old logs:', error);
        }
    }
}

const logger = new Logger();

// Clean up old logs on startup
logger.cleanupOldLogs();

// Schedule daily cleanup
setInterval(() => {
    logger.cleanupOldLogs();
}, 24 * 60 * 60 * 1000); // 24 hours

module.exports = logger;
