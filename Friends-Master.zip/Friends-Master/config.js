require('dotenv').config();

module.exports = {
    // Bot configuration
    token: process.env.DISCORD_TOKEN || 'your_bot_token_here',
    prefix: process.env.PREFIX || '!',
    
    // Database configuration
    database: {
        path: process.env.DB_PATH || './bot_database.sqlite'
    },
    
    // Music configuration
    music: {
        maxQueueSize: parseInt(process.env.MAX_QUEUE_SIZE) || 50,
        defaultVolume: parseInt(process.env.DEFAULT_VOLUME) || 50
    },
    
    // Economy configuration
    economy: {
        dailyAmount: parseInt(process.env.DAILY_AMOUNT) || 100,
        currencyName: process.env.CURRENCY_NAME || 'coins',
        currencySymbol: process.env.CURRENCY_SYMBOL || '🪙'
    },
    
    // Leveling configuration
    leveling: {
        xpPerMessage: parseInt(process.env.XP_PER_MESSAGE) || 15,
        xpCooldown: parseInt(process.env.XP_COOLDOWN) || 60000, // 1 minute
        baseXpRequired: parseInt(process.env.BASE_XP_REQUIRED) || 100
    },
    
    // Rate limiting
    rateLimiting: {
        commandCooldown: parseInt(process.env.COMMAND_COOLDOWN) || 3000, // 3 seconds
        maxCommandsPerMinute: parseInt(process.env.MAX_COMMANDS_PER_MINUTE) || 20
    },
    
    // External APIs
    apis: {
        weatherKey: process.env.WEATHER_API_KEY || 'default_weather_key'
    },
    
    // Bot colors and styling
    colors: {
        primary: '#7289DA',
        success: '#43B581',
        warning: '#FAA61A',
        error: '#F04747',
        info: '#00B0F4'
    }
};
